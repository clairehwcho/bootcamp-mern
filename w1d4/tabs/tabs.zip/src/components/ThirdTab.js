import React from "react";
import style from './Tabs.module.css';

const ThirdTab = () => {
    return (
        <div className={style.thirdTab}>
            <p>This is the third tab</p>
            {/* Third tab content will go here */}
        </div>
    )
}
export default ThirdTab;