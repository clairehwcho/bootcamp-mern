import React from "react";
import style from './Tabs.module.css';

const FirstTab = () => {
    return (
        <div className={style.firstTab}>
            <p>This is the first tab</p>
            {/* First tab content will go here */}
        </div>
    )
}
export default FirstTab;